import { BanLog } from './ban-log';

describe('BanLog', () => {
  it('should create an instance', () => {
    expect(new BanLog()).toBeTruthy();
  });
});
