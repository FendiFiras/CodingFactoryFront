export enum EventType {
    WEBINAR = "WEBINAR",
    WORKSHOP = "WORKSHOP",
    HACKATHON = "HACKATHON",
    MEETUP = "MEETUP"
  }
  