export class Session {
    sessionId: number;
    location: string;
    program: string;
    startTime: Date;
    endTime: Date;
  }
  