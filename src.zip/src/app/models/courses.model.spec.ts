import { Courses } from './courses.model';

describe('Courses', () => {
  it('should create an instance', () => {
    expect(new Courses()).toBeTruthy();
  });
});
