export class UserPreference {
    idPreference?: number;
  theme?: string;
  language?: string;
  notificationEnabled?: boolean;
  
}
