export interface Notification {
    idNotification: number;
    message: string;
    sentDate: string;
  }
  