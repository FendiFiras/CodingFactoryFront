export class QuizAnswer {
    idQuizA?: number; // L'ID peut être optionnel si l'on crée un nouvel objet
    answerText!: string; // Texte de la réponse
    correct!:boolean; // Indique si la réponse est correcte ou non

  }
  