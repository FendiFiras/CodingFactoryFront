export class Quiz {
    idQuiz!: number;
    quizName!: string;
    deadline!: Date;
    minimumGrade!: number;
    timeLimit!: number;
    maxGrade!: number;
}
