import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { pfebackofficeroutingModule } from './pfebackoffice-routing.module';



@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    pfebackofficeroutingModule
  ]
})
export class PfebackofficeModule { }
