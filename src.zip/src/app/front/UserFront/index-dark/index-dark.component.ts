import { Component } from '@angular/core';

@Component({
  selector: 'app-index-dark',
  imports: [],
  templateUrl: './index-dark.component.html',
  styleUrl: './index-dark.component.scss'
})
export class IndexDarkComponent {

}
