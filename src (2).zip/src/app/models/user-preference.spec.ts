import { UserPreference } from './user-preference';

describe('UserPreference', () => {
  it('should create an instance', () => {
    expect(new UserPreference()).toBeTruthy();
  });
});
