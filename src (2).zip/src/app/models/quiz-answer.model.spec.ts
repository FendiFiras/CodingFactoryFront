import { QuizAnswer } from './quiz-answer.model';

describe('QuizAnswer', () => {
  it('should create an instance', () => {
    expect(new QuizAnswer()).toBeTruthy();
  });
});
