export interface Evaluation {
    idEvaluation: number;
    score: number;
    comment: string;
    evaluationPdf: string;

  }