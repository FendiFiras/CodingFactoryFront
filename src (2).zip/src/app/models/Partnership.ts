export class Partnership {
  idPartnership?: number;
  companyName: string;
  industry: string;
  companyWebsite: string;
  companyLogo: string;
}