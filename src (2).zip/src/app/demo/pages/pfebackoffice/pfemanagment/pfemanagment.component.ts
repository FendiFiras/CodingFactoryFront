import { Component } from '@angular/core';
import { SharedModule } from 'src/app/theme/shared/shared.module';

@Component({
  selector: 'app-pfemanagment',
  imports: [SharedModule],
  templateUrl: './pfemanagment.component.html',
  styleUrl: './pfemanagment.component.scss'
})
export class PfemanagmentComponent {

}
